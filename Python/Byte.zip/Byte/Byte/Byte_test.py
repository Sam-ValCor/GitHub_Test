import numpy as np
import cv2 as cv

cv.namedWindow('Canny_Edge')

def nothing(x):
    pass

cv.createTrackbar('Increase','Canny_Edge', 0, 255, nothing)
cv.createTrackbar('Decrease','Canny_Edge', 0, 255, nothing)



face_ext_alg_cas = cv.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_detec_alg  = cv.CascadeClassifier('haarcascade_eye.xml')
cap = cv.VideoCapture(0)

while True:

    ret2, img = cap.read()
    #img= cv.blur(img,(3,3))

    img_Gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    faceMScale = face_ext_alg_cas.detectMultiScale(img_Gray, 1.2, 5)

    Inc = cv.getTrackbarPos('Increase','Canny_Edge')
    Dec = cv.getTrackbarPos('Decrease','Canny_Edge')
    #img = cv.imread("naruto.jpg")

    canny_edge=cv.Canny(img_Gray,Inc,Dec)

    #cv.imshow('Canny_Edge_cam',canny_edge)
    for (x,y, w, h) in faceMScale:

        rect= cv.rectangle(canny_edge,(x,y), (x + w, y + h), (50, 0, 100), 2)
        """ Moment = cv.moments(x,y)
        if Moment["m00"] == 0: Moment["m00"] = 1
        x1 = int(Moment["m10"] / Moment["m00"])
        y1 = int(Moment["m01"] / Moment["m00"])
        cv.circle(img, (x1, y1), 5, (18, 156, 243), -1)
        """
        r_gray = img_Gray[y:y + h, x:x + w]
        r_color = canny_edge[y:y + h, x:x + w]
        eyes = eye_detec_alg.detectMultiScale(r_color, 1.2, 5)
        for (ex, ey, ew, eh) in eyes:
            cv.rectangle(r_color, (ex, ey), (ex + ew, ey + eh), (50, 0, 100), 2)
    cv.imshow('Canny_Edge',canny_edge)
    #print("X:", x, " Y: ", y, " W: ", w, "H: ", h)
    if cv.waitKey(1) == ord('e'):
       cv.destroyAllWindows()
       break

#img.show()
cap.release()
cv.destroyAllWindows()
